<?php

return [
    'site_title' => 'Rekonomi',
];
